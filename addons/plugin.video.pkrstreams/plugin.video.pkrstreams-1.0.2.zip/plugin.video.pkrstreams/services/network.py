"""
Network Service for handling networking related tasks
"""

from requests_cache import CachedSession as Session
from requests.adapters import HTTPAdapter, Retry
from requests.exceptions import RequestException

retry = Retry(total=6, backoff_factor=0.5, status_forcelist=[502, 503, 504])
cache_options = {'streamblasters.*/wp-json/wp/v2/posts*': 3600}

def create_session(cache_path=None):
    """Session creator"""
    assert cache_path
    service = Session(
        cache_path,
        stale_if_error=True,
        allowable_codes=[200],
        urls_expire_after=cache_options,
        expire_after=300)
    service.mount('https://', HTTPAdapter(max_retries=retry))
    service.verify = False
    service.cache.delete(expired=True, invalid=True) # for storage efficiency
    return service


def exception_safe(function):
    """Wrapper to provide exception safe requests"""
    def wrapper(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except RequestException as exception:
            print(exception)
            return None
    return wrapper


@exception_safe
def GET(service, *args, **kwargs):
    """GET Request wrapper"""
    return service.get(*args, **kwargs)
