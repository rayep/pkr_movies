"""
Network Service for handling networking related tasks
"""

from requests_cache import CachedSession as Session
from requests.adapters import HTTPAdapter, Retry
from requests.exceptions import RequestException
from lib.utils import get_file_created_time, file_checker, file_deleter

retry = Retry(total=6, backoff_factor=0.5, status_forcelist=[502, 503, 504])
cache_options = {'streamblasters.*/wp-json/wp/v2/posts*': 3600}

def create_session(cache_path=None):
    """Session creator"""
    assert cache_path
    cache_path_real = f"{cache_path}.sqlite"
    if file_checker(cache_path_real):
        cache_created_time = get_file_created_time(cache_path_real)
        if cache_created_time > 604800:
            file_deleter(cache_path_real)
    service = Session(
        cache_path,
        allowable_codes=[200],
        urls_expire_after=cache_options,
        expire_after=300)
    service.mount('https://', HTTPAdapter(max_retries=retry))
    service.verify = False
    service.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36'}
    return service


def exception_safe(function):
    """Wrapper to provide exception safe requests"""
    def wrapper(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except RequestException as exception:
            print(exception)
            return None
    return wrapper


@exception_safe
def GET(service, *args, **kwargs):
    """GET Request wrapper"""
    return service.get(*args, **kwargs)
