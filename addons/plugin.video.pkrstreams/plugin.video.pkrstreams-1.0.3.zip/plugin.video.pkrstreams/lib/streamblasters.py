"""
Streamblasters parser library
"""

from lib.parser import regex_match

MOVIES_CDN_LINK = r'.*src="(?P<url>([\w\W]+?))"'
MOVIES_DIRECT_LINK = r'.*sources: \[\{file:"(?P<url>([\w\W]+?))"\}\]'
STREAMBLASTERS = 'https://streamblasters.pm/wp-json'

class StreamBlasters():
    """Streamblaster API Response Parser"""

    categories={'2024 Tamil Movies': 2366}
    urls = {
        'posts': f'{STREAMBLASTERS}/wp/v2/posts'
    }

    @staticmethod
    def parse_movies_cdn_links(raw_response):
        """Get Movies from /wp/v2/posts API"""
        movies = raw_response.json()
        return {
            movie['title']['rendered']:  # Movie Name
            # [{movie['cmb2']['video_player_settings']['original_video_title']:
            #     urlParse(movie['cmb2']['video_player_settings']['vm_video_url'])}] # Source-1
            #     +
            {_movie['ml_label']:  # Source 2 & 3
                regex_match(MOVIES_CDN_LINK, _movie['ml_url']) \
              for _movie in movie['cmb2']['video_player_settings']['vm_video_multi_links']}
            for movie in movies}

    @staticmethod
    def parse_movies_direct_links(raw_response):
        """Parse movies from CDN responses"""
        links = raw_response.content.decode()
        return regex_match(MOVIES_DIRECT_LINK, links, 16)
