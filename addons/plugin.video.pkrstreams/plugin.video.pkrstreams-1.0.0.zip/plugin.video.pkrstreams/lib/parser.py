"""
Parser collections library
"""

import re

def regex_match(pattern, string, flags=None):
    """Regex matcher"""
    matched = re.match(pattern, string) if not flags else re.match(pattern, string, flags)
    return matched.group('url') if matched else None
