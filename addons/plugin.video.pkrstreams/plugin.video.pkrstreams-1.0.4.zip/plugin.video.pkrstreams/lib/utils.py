"""
General Utils
"""

import os
from datetime import datetime


def get_file_created_time(filepath: str):
    """Get difference between last file modified - today in seconds"""
    now = datetime.now()
    file_stat = os.path.getctime(filepath)
    file_stat_dtime = datetime.fromtimestamp(file_stat)
    # get total seconds of the time elapsed.
    return (now-file_stat_dtime).total_seconds()


def file_checker(filepath):
    """File existence checker"""
    return os.path.exists(filepath)


def file_deleter(filepath):
    """File deleter"""
    return os.remove(filepath)
