"""
PKR Stream App
"""

import os
from xbmc import Player
from xbmcvfs import translatePath
from xbmcaddon import Addon
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory
from routing import Plugin
from lib.streamblasters import StreamBlasters
from services.network import create_session, GET, POST, GET_BS


ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
CACHE_FILE = os.path.join(ADDON_PATH, 'streamblasters')
PKRSTREAMS_API = "https://pkrmovies-api.onrender.com/streams"
network_service = create_session(CACHE_FILE)
streamblasters = StreamBlasters()
plugin = Plugin()


def create_movie_item(label):
    """Make the URL as playable item"""
    list_item = ListItem(label)
    info_tag = list_item.getVideoInfoTag()
    info_tag.setMediaType('video')
    info_tag.setTitle(label)
    list_item.setProperty('IsPlayable', 'true')
    return list_item


@plugin.route('/')
def show_category():
    """Index page handler"""
    for name, category_id in streamblasters.categories.items():
        addDirectoryItem(plugin.handle, plugin.url_for(
            show_movies, category_id), ListItem(name), True)
    endOfDirectory(plugin.handle)


@plugin.route('/category/<category_id>')
def show_movies(category_id):
    """List movies in the selected category"""
    movies = GET(network_service, streamblasters.urls['posts'], params={
                 'categories': category_id, 'per_page': 30})
    movies_cdn_links = streamblasters.parse_movies_cdn_links(movies)
    for movie_name in movies_cdn_links:
        addDirectoryItem(
            plugin.handle,
            plugin.url_for(
                show_movie_sources,
                category_id=category_id,
                movie=movie_name),
            ListItem(movie_name),
            True)
    endOfDirectory(plugin.handle)


@plugin.route('/category/<category_id>/movie/<movie>')
def show_movie_sources(category_id, movie):
    """List Selected Movie Sources"""
    movies = GET(network_service, streamblasters.urls['posts'], params={
                 'categories': category_id, 'per_page': 30})
    movies_cdn_links = streamblasters.parse_movies_cdn_links(movies)
    for movie_name, movie_sources in movies_cdn_links.items():
        if movie_name == movie:
            for source_name, source_url in movie_sources.items():
                addDirectoryItem(
                    plugin.handle,
                    plugin.url_for(
                        get_play_link,
                        movie=movie_name,
                        url=f"{source_url}"),
                    ListItem(source_name),
                    True)
    endOfDirectory(plugin.handle)


@plugin.route('/movie/<path:movie>/url/<path:url>')
def get_play_link(movie, url):
    """Get direct play link from CDN source"""
    request = GET(network_service, url)
    direct_link = streamblasters.parse_movies_direct_links(request)
    movie_item = create_movie_item(movie)
    if direct_link:
        Player().play(direct_link, movie_item)
    else:
        obfs_data = GET_BS(url)
        encoded_obfs_data = streamblasters.extract_encode_obfuscated_links(obfs_data)
        request = POST(url=PKRSTREAMS_API, json={'name': movie, 'source': url, 'data': encoded_obfs_data})
        direct_link = streamblasters.parse_deobfus_movie_links(request)
        Player().play(direct_link, movie_item)

if __name__ == '__main__':
    plugin.run()
