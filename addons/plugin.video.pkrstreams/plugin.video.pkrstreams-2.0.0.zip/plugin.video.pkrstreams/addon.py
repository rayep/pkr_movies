"""
PKR Stream App
"""

import os
import json
from xbmc import Player
from xbmcvfs import translatePath
from xbmcaddon import Addon
from xbmcgui import ListItem, Window
from xbmcplugin import addDirectoryItem, endOfDirectory
from routing import Plugin
from lib.tools import pipe
from lib.deobfuscator import deobfus_js_packed_links, extract_script_links
from lib.parser import parse_source_1_url, parse_source_2_3_urls, remove_dood_cdn_links
from services.network import create_session, GET, GET_BS


ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
CACHE_FILE = os.path.join(ADDON_PATH, 'streamblasters')
STREAMBLASTERS_CATEGORIES = {'2024 Tamil Movies': 2366}
STREAMBLASTERS_POSTS = 'https://streamblasters.pm/wp-json/wp/v2/posts'

network_service = create_session(CACHE_FILE)
plugin = Plugin()
window = Window(10000)  # XBMC Window ID for storing variable values.


def sb_parse_movie_source_links(state):
    """Get Movies from /wp/v2/posts API"""
    raw_movies = state['raw_movies']
    parse_movies = pipe(parse_source_1_url, parse_source_2_3_urls, remove_dood_cdn_links)
    movie_source_links = list(map(parse_movies, raw_movies))
    state.pop('raw_movies')
    state.update({'movies': movie_source_links})
    return state


def sb_fetch_movies_list(state):
    """Fetch Movies from Streamblasters API"""
    fetched_movies = GET(network_service, STREAMBLASTERS_POSTS, params={
                         'categories': state['category'], 'per_page': 50}).json()
    state.update({'raw_movies': fetched_movies})
    return state

def create_movie_item(label):
    """Make the URL as playable item"""
    list_item = ListItem(label)
    info_tag = list_item.getVideoInfoTag()
    info_tag.setMediaType('video')
    info_tag.setTitle(label)
    list_item.setProperty('IsPlayable', 'true')
    return list_item


@plugin.route('/')
def show_category():
    """Index page handler"""
    for name, category_id in STREAMBLASTERS_CATEGORIES.items():
        addDirectoryItem(plugin.handle,
                         plugin.url_for(show_movies, category_id),
                         ListItem(name),
                         True)
    endOfDirectory(plugin.handle)


@plugin.route('/category/<category_id>')
def show_movies(category_id):
    """List movies in the selected category"""
    fetch_movies = pipe(sb_fetch_movies_list, sb_parse_movie_source_links)(
        {'category': category_id})
    window.setProperty('movies', json.dumps(fetch_movies['movies']))
    for index, movie in enumerate((fetch_movies)['movies']):
        addDirectoryItem(plugin.handle,
                         plugin.url_for(show_movie_sources,
                                        category_id=category_id, index=index),
                         ListItem(movie['name']),
                         True)
    endOfDirectory(plugin.handle)


@plugin.route('/category/<category_id>/movie/<index>')
def show_movie_sources(category_id, index):
    """List Selected Movie Sources"""
    selected_movie = json.loads(window.getProperty('movies'))[int(index)]
    for source_name, source_url in selected_movie['source_links'].items():
        addDirectoryItem(plugin.handle,
                         plugin.url_for(
                             get_play_link, movie=selected_movie['name'], url=f"{source_url}"),
                         ListItem(source_name),
                         True)
    endOfDirectory(plugin.handle)


@plugin.route('/movie/<path:movie>/url/<path:url>')
def get_play_link(movie, url):
    """Get direct play link from CDN source"""
    play_link = url
    movie_item = create_movie_item(movie)
    if 'iplayerhls' in url:
        obfs_data = GET_BS(url)
        play_link = deobfus_js_packed_links(obfs_data)
    elif 'dhtpre' in url:
        obfs_data = GET_BS(url)
        play_link = deobfus_js_packed_links(obfs_data)
    elif 'luluvdo' in url:
        obfs_data = GET_BS(url)
        play_link = extract_script_links(obfs_data)
    else:  # Try for all other links - might work! :)
        obfs_data = GET_BS(url)
        play_link = deobfus_js_packed_links(obfs_data)
        if not play_link:
            play_link = extract_script_links(obfs_data)
    Player().play(play_link, movie_item)


if __name__ == '__main__':
    plugin.run()
