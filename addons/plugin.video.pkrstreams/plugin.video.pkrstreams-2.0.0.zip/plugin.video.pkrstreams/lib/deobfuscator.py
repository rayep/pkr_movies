"""De-obfuscator for JavaScript obfuscated code"""

import re
from .tools import check_regex_pattern

REGEX_URL_FORMAT_OBFUS = r'[\w\W]+?\[\{[\w\W]+?:\"(?P<pattern>([\w\W]+?))\"\}\]'
REGEX_URL_CONTENT_OBFUS = r'[\w\W\d\D\s\S]+[\"\']\|(?P<pattern>(.*))[\"\']\.'

def to_base36(n):
    """Convert a number to base-36 string (like JavaScript's toString(36))"""
    return base_convert(n, 36)


def base_convert(num, base):
    """Python equivalent of JavaScript's toString(36)"""
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    if num == 0:
        return digits[0]
    result = []
    while num:
        result.append(digits[num % base])
        num //= base
    return ''.join(reversed(result))


def deobfuscator(char, url, content):
    """Main de-obfuscator"""
    while (char):
        char -= 1
        if content[char]:
            url = re.sub(r'\b'+to_base36(char)+r'\b', content[char], url)
    return url

def deobfus_js_packed_links(html_data):
    """De-obfuscate CDN links for direct play m3u8 links"""
    for script in html_data.find_all("script"):
        if "[{" in script.text:
            url_format_obfus = check_regex_pattern(
                REGEX_URL_FORMAT_OBFUS, script.text, 'pattern')
            url_content_obfus = "|" + \
                check_regex_pattern(REGEX_URL_CONTENT_OBFUS,
                                    script.text, 'pattern')
            content_len = len(url_content_obfus.split('|'))
            return deobfuscator(content_len, url_format_obfus, url_content_obfus.split('|'))
    return ''


def extract_script_links(html_data):
    """Extract script links from HTML data - non-obfuscated links"""
    for script in html_data.find_all("script"):
        if "[{" in script.text:
            direct_play_link = check_regex_pattern(
                REGEX_URL_FORMAT_OBFUS, script.text, 'pattern')
            return direct_play_link
    return ''