"""Streamblasters Parser Module"""

from .tools import regex_match

REGEX_MOVIES_CDN_LINK = r'.*src="(?P<url>([\w\W]+?))"'
REGEX_MOVIES_DIRECT_LINK = r'.*sources: \[\{file:"(?P<url>([\w\W]+?))"\}\]'

def parse_source_1_url(movie):
    """Parse Source-1 URL"""
    movie_name = movie['title']['rendered']
    source_name = movie['cmb2']['video_player_settings']['original_video_title']
    source_1_url = regex_match(
        REGEX_MOVIES_CDN_LINK, movie['cmb2']['video_player_settings']['vm_video_url'])
    return {'name': movie_name, 'source_links': {source_name: source_1_url}, 'raw_movie': movie}


def parse_source_2_3_urls(movie):
    """Parse Source-2 & 3 URLs"""
    raw_movie = movie['raw_movie']
    for _movie in raw_movie['cmb2']['video_player_settings']['vm_video_multi_links']:
        source_name = _movie['ml_label']
        source_url = regex_match(REGEX_MOVIES_CDN_LINK, _movie['ml_url'])
        movie['source_links'].update({source_name: source_url})
    movie.pop('raw_movie')
    return movie


def remove_dood_cdn_links(movie):
    """Remove Dood CDN links from movie sources"""
    movie['source_links'] = {source_name: source_url
                             for source_name, source_url in movie['source_links'].items()
                             if 'dood' not in source_url}
    return movie