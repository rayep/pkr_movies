"""
Tools module for utility functions.

"""
from functools import reduce
import re


def regex_match(pattern, string, flags=None):
    """Regex matcher"""
    matched = re.match(pattern, string) if not flags else re.match(
        pattern, string, flags)
    return matched.group('url') if matched else None


def _piper(acc, func):
    return func(acc)


def pipe(*functions):
    """Pipe utility for composing functions. Returns a composed function."""
    def composed_function(*args, **kwargs):
        return reduce(_piper, functions[1:], functions[0](*args, **kwargs))
    return composed_function

def check_regex_pattern(pattern, string, group):
    """RegEx pattern check and extract group value"""
    result = re.match(pattern, string)
    return result.group(group) if result else ''
