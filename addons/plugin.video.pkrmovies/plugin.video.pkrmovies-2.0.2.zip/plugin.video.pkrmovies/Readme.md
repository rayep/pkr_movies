# PKR Movies plugin for Kodi mediacenter

v1.0.0 - Initial release.

v1.0.1 -
Fixed parse player urls missing one of more Vimeo links.
Added counter for retry.

v1.0.2 -
Deobfuscated arivakam player links.
Added movie links caching mechanism.
Added parsing & M3U8 support for PlayAllu CDN links.

v1.0.3 -
Added checks for movie links.

v1.0.4 -
Corrected updated movie links.
Corrected local links expiry check timer (reduced to ~3hrs)