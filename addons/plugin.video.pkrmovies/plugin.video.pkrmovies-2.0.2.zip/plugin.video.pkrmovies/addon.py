"""
Kodi Addon - PKR Movies
Movies powered by @TamilGun

Author: Ray A.
"""

import sys
import os
import re
import random
import json
import socket
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from threading import Thread
from datetime import datetime
from html import unescape
from collections import OrderedDict
from time import sleep
from urllib.parse import urlencode, parse_qsl, unquote
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup
from requests import Session
from urllib3 import disable_warnings
from requests.exceptions import ConnectionError, SSLError
from xbmcaddon import Addon
from xbmcvfs import translatePath
disable_warnings()

# Get the plugin url in plugin:// notation.
URL = sys.argv[0]
# Get a plugin handle as an integer number.
HANDLE = int(sys.argv[1])
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
DATA = os.path.join(ADDON_PATH, 'data')
M3U8 = os.path.join(ADDON_PATH, 'm3u8')
LINKS = os.path.join(ADDON_PATH, 'links')

PLAYALLU_BODY = {'referrer':'https://player2.arivakam.net','typeend':'html'}
PLAYALLU_API_BYPASS = {'data_url': 'https://pkrmovies-api.onrender.com/', 'play_url': 'https://pkrmovies-api.onrender.com/play'}

M3U_HEADER = """#EXTM3U
#EXT-X-PLAYLIST-TYPE:VOD
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:1
"""

M3U_FOOTER = """
#EXT-X-ENDLIST
"""

def m3u8_stream_creator(duration: int, url: str):
    """EXTINF entry creator"""
    return f"""
#EXTINF:{duration},
{url}
"""

def char_finder(char, max_no):
    """Char finder - JS de-obfuscator"""
    base36_values = '0123456789abcdefghijklmnopqrstuvwxyz'
    condition1 = "" if char < max_no else char_finder(int(char/max_no), max_no)
    def sub_char_finder(sub_char, max_no):
        """Sub function"""
        sub_char = sub_char % max_no
        return chr(sub_char+29) if sub_char > 35 else base36_values[int(sub_char)]
    return condition1+sub_char_finder(char, max_no)

def main_deobfuscator(char, max_no, url, content):
    """Main de-obfuscator"""
    while (char):
        char -= 1
        if content[char]:
            url = re.sub(rf'\b{char_finder(char, max_no)}\b', content[char], url)
    if 'http' not in url:
        return '' #if not valid HTTP link found after deobfus.
    return url

def check_regex_pattern(pattern, string, group):
    """RegEx pattern check and extract group value"""
    result = re.match(pattern, string)
    return result.group(group) if result else ''

def dict_updater(new_dict : dict, store_dict: dict, remove_key: str = ''):
    """Check if new value is present before merging to main dict"""
    if list(new_dict.values())[0] not in store_dict.values():
        store_dict.update(new_dict)
        _ = store_dict.pop(remove_key) if remove_key else None
        # removing the key from original dict is needed as either the link is duplicate
        # or got transformed to valid movie link.
    return store_dict

def get_last_modified_time(filepath: str):
    """Get difference between last file modified - today in seconds"""
    now = datetime.now()
    file_stat = os.path.getmtime(filepath)
    file_stat_dtime = datetime.fromtimestamp(file_stat)
    return (now-file_stat_dtime).total_seconds() # get total seconds of the time elapsed.

def strip_notsafe_chars(string: str):
    """Strip not safe chars from being added to filesystem"""
    return string.translate({ord(i): None for i in r'\./*?<>"|:'})


class RelayHTTPServerHandler(BaseHTTPRequestHandler):
    """Main class for the PlayAllu M3U8 stream request"""
    def __init__(self, request,client_address, server) -> None:
        super().__init__(request, client_address, server)

    def do_GET(self):
        """Send GET - relay request to original PlayAllu API"""
        # Reversing the split order as the host param would be having the original URL |host=<URL>
        response = session.get(url='https://str01.strplayallu01.site'+self.path)
        self.send_response(response.status_code)
        for header, value in response.headers.items():
            self.send_header(header, value)
        self.end_headers()
        self.wfile.write(response.content)

def relay_config(port, server, handler):
    """Executor of relay service"""
    address = ('127.0.0.1', port)
    httpd = server(address, handler)
    httpd.serve_forever()

def playallu_stream_relay():
    """Stream relay socket for loading the M3u8 stream content"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    if sock.connect_ex(('127.0.0.1', 9025)):
        thread = Thread(target=relay_config, args=(9025, ThreadingHTTPServer, RelayHTTPServerHandler))
        thread.daemon = True
        thread.start()
    sock.close()


class TamilGun():
    """TamilGun Movies"""
    TRENDING = "https://tamilgun.group/trending/"
    HD_MOVIES = "https://tamilgun.group/video-category/hd-movies/"

    def __init__(self) -> None:
        self.trending_movies = {}
        self.hd_movies = {}
        self.icons = {}
        self.player_cdns = {}
        self.player_links = {}
    
    def _get_movies(self, html_data: BeautifulSoup):
        """Get Movies"""
        movies = OrderedDict()
        for movie in html_data.find_all('article'):
            parsed_movie = movie.findNext('div').findNext('h3').findNext('a').attrs
            # parsed_icon = movie.findNext('div').findNext('a').findNext('img').attrs
            movies.update({strip_notsafe_chars(parsed_movie['title']):parsed_movie['href']})
        return movies

    def get_trending_movies(self, page: int, html_data: BeautifulSoup):
        """Get Trending Movies"""
        page = int(page)
        self.trending_movies[page] = self._get_movies(html_data)
        with open(f"{DATA}{os.sep}trending{page}", mode='w', encoding='utf-8') as file:
            json.dump(self.trending_movies[page], file)
        return self.trending_movies[page]

    def get_hd_movies(self, page: int, html_data: BeautifulSoup):
        """Get Trending Movies"""
        page = int(page)
        self.hd_movies[page] = self._get_movies(html_data)
        with open(f"{DATA}{os.sep}hd{page}", mode='w', encoding='utf-8') as file:
            json.dump(self.hd_movies[page], file)
        return self.hd_movies[page]

    def parse_links_directly_scriptdata(self, html_data: BeautifulSoup) -> str:
        """Parses video_url data from Movie page - within <iframe> embedded inside <script> data"""
        for script in html_data.find_all('script'):
            if (not script.attrs) and ("video_url" in script.text):
                iframe_elem = BeautifulSoup(
                    script.text[script.text.find('<iframe'):script.text.find(r'</iframe>')], 'html.parser')
                return iframe_elem.find('iframe').attrs['src'].replace("\\","").strip('"')
        return ''

    def parse_all_player_links(self, html_data: BeautifulSoup):
        """Parse All player links such Vimeo, arivakam, playallu directly from the movie page"""
        links = {}
        for article in html_data.find_all('li'):
            link = article.attrs.get('data-video')
            name = article.text if article.text else f"Player-{random.randint(5,7)}"
            if 'vimeo' in link: # Vimeo links
                dict_updater({name:unescape(link)}, links)
            elif 'api_player.php' in article.attrs['data-video']: # Arivakam links
                dict_updater({name:f"https://player2.arivakam.net/player/{link.replace('default', 'hls')}"}, links)
            else: # Might be PlayAllu or others.
                dict_updater({name:link}, links)
        # Sometimes script data would be contain other movie links - but mostly it'll be playallu.
        for tag in html_data.find_all("script"):
            if 'link_play' in tag.text:
                text1 = unescape(tag.text[tag.text.find('link_play = ')+12:])
                text2 = text1[:text1.find(';')]
                dict_updater({f"Player-{random.randint(5,7)}":json.loads(text2)[0]['file']}, links)
        return links
    
    def parse_arivakam_links(self, html_data: BeautifulSoup):
        """Parse Arivakam links for new movie links"""
        for script in html_data.find_all("script"):
            if "[{" in script.text:
                url_format_obfus_raw = json.loads('{'+check_regex_pattern(r'[\w\W\d\D\s\S]+\[\{(?P<pattern>(.*))\}\]', script.text, 'pattern')+'}')
                url_format_obfus = url_format_obfus_raw[list(url_format_obfus_raw)[0]]
                url_content_obfus = "|" + check_regex_pattern(r'[\w\W\d\D\s\S]+[\"\']\|(?P<pattern>(.*))[\"\']\.', script.text,'pattern')
                if url_format_obfus and url_content_obfus:
                    content_len = len(url_content_obfus.split('|'))
                    return main_deobfuscator(content_len, content_len, url_format_obfus, url_content_obfus.split('|'))
        return ''

    def parse_vimeo_links(self, html_data: BeautifulSoup):
        """Parse Vimeo CDN links"""
        links = {}
        for script in html_data.find_all('script'):
            if (not script.attrs) and 'cdn_url' in script.text:
                script_raw = unescape(script.text)
                test_eval = script_raw[script_raw.find('{'):]
                for cdn, url in json.loads(test_eval)['request']['files']['hls']['cdns'].items():
                    links.update({cdn:url['avc_url']})
        return links

    def parse_playallu_details(self, html_data: BeautifulSoup):
        """Parse PlayAllu CDN details"""
        playallu_details = {}
        for script in html_data.find_all("script"):
            if "idUser" in script.text:
                iduser_pattern = check_regex_pattern(r'[\w\W\d\D\s\S]+idUser = [\"\'](?P<idUser>(\w+))[\"\']\;', script.text, 'idUser')
                if iduser_pattern:
                    playallu_details.update({'idUser': iduser_pattern})
                else:
                    iduser_pattern = check_regex_pattern(r'[\w\W\d\D\s\S]+idUser_enc = [\"\'](?P<idUser>(\w+))[\"\']\;', script.text, 'idUser')
                    if iduser_pattern:
                        playallu_details.update({'idUser': iduser_pattern})
                        idfile_pattern = check_regex_pattern(r'[\w\W\d\D\s\S]+idfile_enc = [\"\'](?P<idfile>(\w+))[\"\']\;', script.text, 'idfile')
                        if idfile_pattern:
                            playallu_details.update({'idfile': idfile_pattern})
            if "DOMAIN_API" in script.text:
                # type_end = re.match(r'[\w\W\d\D\s\S]+TYPEEND = [\"\'](?P<typeend>(\w+?))[\"\']\;', script.text).group('typeend')
                domain_api = check_regex_pattern(r'[\w\W\d\D\s\S]+DOMAIN_API = [\"\'](?P<domainapi>(.+?))[\"\']\;', script.text, 'domainapi')
                domain_list = check_regex_pattern(r'[\w\W\d\D\s\S]+DOMAIN_LIST_RD = (?P<domainlist>(.+?))\;', script.text,'domainlist')
                domain_api_info = check_regex_pattern(r'[\w\W\d\D\s\S]+DOMAIN_API_Info = [\"\'](?P<domainapiinfo>(.+?))[\"\']\;', script.text, 'domainapiinfo')
                domain_api_view = check_regex_pattern(r'[\w\W\d\D\s\S]+DOMAIN_API_VIEW = [\"\'](?P<domainapiview>(.+?))[\"\']\;', script.text, 'domainapiview')
                if domain_api:
                    playallu_details.update({ 'domain_api': domain_api})
                if domain_list:
                    playallu_details.update({'domain_list':json.loads(domain_list)})
                if domain_api_info:
                    playallu_details.update({'domain_api_info': domain_api_info})
                if domain_api_view:
                    playallu_details.update({'domain_api_view': domain_api_view})
        return playallu_details

    def write_playallu_m3u8_old(self, raw_response: bytes, domain_url: str, movie_name: str):
        """Parse & Write PlayAllu M3U8 files to disk"""
        json_response = json.loads(raw_response)
        durations = json_response['data'][0]
        segments = [f"https://{domain_url}/stream/v5/{segment}.html" for segment in json_response['data'][1]]
        if segments:
            with open(f"{M3U8}/{movie_name}.m3u8", mode='w', encoding='utf-8') as ofile:
                ofile.write(M3U_HEADER)
                ofile.writelines(list(map(m3u8_stream_creator, durations, segments)))
                ofile.write(M3U_FOOTER)

    def write_playallu_m3u8_new(self, raw_response: bytes, movie_name: str):
        """Parse & Write PlayAllu M3U8 files to disk"""
        m3u8_response = re.sub(r'(http([\w])://[\w\d\W]+?)/(.*)', r'http://localhost:9025/\3', raw_response.decode())
        if m3u8_response:
            with open(f"{M3U8}/{movie_name}.m3u8", mode='w', encoding='utf-8') as ofile:
                ofile.write(m3u8_response)

session = Session()
session.headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
    'Referer': 'https://tamilgun.group/'}
session.verify = False
#session.proxies = {'https': 'http://127.0.0.1:8888'}

tamilgun = TamilGun()
playallu_stream_relay()


def get(url, raw=False):
    """GET Request"""
    if raw:
        return session.get(url, allow_redirects=True).content
    else:
        try:
            return BeautifulSoup(session.get(url, allow_redirects=True).content.decode(), 'html.parser')
        except (ConnectionError, SSLError):
            print("Connection Error. Retrying...")
            sleep(3)
            return get(url)

def post(url, **kwargs):
    """POST Request"""
    try:
        return session.post(url, allow_redirects=True, **kwargs).content
    except (ConnectionError, SSLError):
        print("Connection Error. Retrying...")
        sleep(3)
        return post(url, **kwargs)
    except KeyboardInterrupt:
        raise SystemExit() from None

def get_kodi_url(**kwargs):
    """Create a URL for calling the plugin recursively from the given set of keyword arguments."""
    return f'{URL}?{urlencode(kwargs)}'

def load_movies_type():
    """Load movies listings into Kodi"""
    categories = [{'trending': 'Trending Movies'}, {'hd':'HD Movies'}]
    xbmcplugin.setPluginCategory(HANDLE, category='TamilGun Movies')
    xbmcplugin.setContent(HANDLE, content='movies')
    for category in categories:
        for cat_type, name in category.items():
            list_item = xbmcgui.ListItem(label=name)
            info_tag = list_item.getVideoInfoTag()
            info_tag.setMediaType('video')
            info_tag.setTitle(name)
            url = get_kodi_url(action='category', category=cat_type)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def load_movies(category: str, page: int, movies: OrderedDict):
    """Load movies listings into Kodi"""
    xbmcplugin.setPluginCategory(HANDLE, category='TamilGun Movies')
    xbmcplugin.setContent(HANDLE, content='movies')
    for movie in movies:
        list_item = xbmcgui.ListItem(label=movie)
        info_tag = list_item.getVideoInfoTag()
        info_tag.setMediaType('video')
        info_tag.setTitle(movie)
        url = get_kodi_url(action='movie', category=category, name=movie, page=page)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_player_links(movie_name:str, player_links: dict):
    """Parse and show player links to user"""
    xbmcplugin.setPluginCategory(HANDLE, category='TamilGun Movies')
    xbmcplugin.setContent(HANDLE, content='movies')
    for player, link in player_links.items():
        list_item = xbmcgui.ListItem(label=f"{movie_name}-{player}")
        info_tag = list_item.getVideoInfoTag()
        info_tag.setMediaType('video')
        info_tag.setTitle(f"{movie_name}-{player}")
        list_item.setProperty('IsPlayable', 'true')
        url = get_kodi_url(action='play', url=link)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(path):
    """Play a video by the provided path."""
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath(path)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)

def update_vimeo_links(original_dict: dict):
    """Update Vimeo CDN links to the player links dict"""
    for key, url in original_dict.copy().items():
        if ('vimeo' in url) and ('m3u8' not in url):
            new_player_links = tamilgun.parse_vimeo_links(html_data=get(url))
            if new_player_links:
                original_dict.update(new_player_links)
                # Not filtering for any duplicate movie links for VIMEO, because it'll be a dict of
                # multiple unique CDN links - NOT arivakam or playallu links.
                original_dict.pop(key) # for renaming the key name in the next step - exception only for VIMEO as the input
                # will be a dict - other "update" method will be removing the key using "dict_updater" function.
            else:
                original_dict.pop(key) # remove if no valid movie link
    return original_dict

def update_arivakam_links(original_dict: dict):
    """Update Arivakam CDN links to the player links dict"""
    for key, url in original_dict.copy().items():
        if 'api_player' in url:
            new_player_links = tamilgun.parse_arivakam_links(html_data=get(url))
            if new_player_links:
                # Avoid adding movie links that are duplicates i.e.,
                # Sometimes mutliple arivakam provides the same PlayAllu links.
                dict_updater({key:new_player_links}, original_dict)
                original_dict.pop(key) # for renaming the key name in the next step.
            else:
                original_dict.pop(key) # remove if no valid movie link
    return original_dict

def update_playallu_links(original_dict: dict, movie_name: str):
    """Update Playallu local M3U8 links to player links dict"""
    for key, url in original_dict.copy().items():
        if 'playallu' in url:
            playallu_id = url.split('/')[-1]
            playallu_details = tamilgun.parse_playallu_details(get(url))
            if playallu_details:
                if playallu_details.get('domain_list'): # only go with this flow if 'domain_list' URL is found
                    playallu_domain = random.choice(playallu_details['domain_list'])
                    playallu_url = f"{playallu_details['domain_api']}{playallu_details['idUser']}/{playallu_id}"
                    tamilgun.write_playallu_m3u8_old(post(url=playallu_url, data=PLAYALLU_BODY), domain_url=playallu_domain, movie_name=movie_name)
                    dict_updater({"PlayAllu_Old": os.path.join(M3U8,f"{movie_name}.m3u8")}, original_dict, key)
                elif playallu_details.get('domain_api'):
                    enc_ip_time_others = json.loads(get(playallu_details.get('domain_api_info'), raw=True)) if playallu_details.get('domain_api_info') else ''
                    _ = get(playallu_details.get('domain_api_view')+playallu_id) if playallu_details.get('domain_api_view') else False # Dummy GET request per the workflow
                    for name, value in playallu_details.items():
                        if name in ('idUser','idfile'):
                            enc_ip_time_others.update({name:value})
                    enc_recv_data = json.loads(post(url=PLAYALLU_API_BYPASS['data_url'], json=enc_ip_time_others))
                    enc_send_data = enc_recv_data['data'] if enc_recv_data.get('data') else {}
                    # Send the encrypted data for getting encrypted M3u8 data
                    enc_playframe_req = json.loads(post(url=playallu_details.get('domain_api'), data={'data': enc_send_data}))
                    if enc_playframe_req.get('data'): # Original M3u8 Encrypted data from PlayAllu
                        play_m3u8_url = json.loads(post(url=PLAYALLU_API_BYPASS['play_url'], json={'data': enc_playframe_req['data']}))
                        if play_m3u8_url.get('data'): # If my API responds correctly.
                            tamilgun.write_playallu_m3u8_new(get(url=play_m3u8_url['data'], raw=True), movie_name)
                            dict_updater({"PlayAllu_New": os.path.join(M3U8,f"{movie_name}.m3u8")}, original_dict, key)
                        else: # if my PlayAllu server did not respond with valid "data" json - remove the key.
                            original_dict.pop(key) 
                    else: # if my PlayAllu server did not respond with valid "data" json - remove the key.
                        original_dict.pop(key)
            else: # iF not a valid playallu details dict - remove the key.
                original_dict.pop(key)
    return original_dict

def local_movie_links_checker(movie_name: str):
    """Movie links checker in local filesystem and returns diff b/w last modified
    & current time in seconds"""
    movie_links_path = f"{LINKS}{os.sep}{movie_name}"
    if os.path.exists(movie_links_path):
        diff_seconds = get_last_modified_time(movie_links_path)
        return diff_seconds
    return 0

def write_movie_links(movie_name: str, movie_links: dict):
    """Write movie links to local filesystem"""
    movie_links_path = f"{LINKS}{os.sep}{movie_name}"
    with open(movie_links_path, mode='w', encoding='utf-8') as ofile:
        json.dump(movie_links, ofile)

def read_movie_links(movie_name: str):
    """Read movie links to local filesystem"""
    movie_links_path = f"{LINKS}{os.sep}{movie_name}"
    with open(movie_links_path, mode='r', encoding='utf-8') as ofile:
        return json.load(ofile)

def delete_movie_links(movie_name: str):
    """Delete movie links from local filesystem"""
    movie_links_path = f"{LINKS}{os.sep}{movie_name}"
    if os.path.exists(movie_links_path):
        os.remove(movie_links_path)

def uow_fetch_player_links(selected_movie_link: str, selected_movie: str):
    """Unit of work: Fetches player link for the selected movie"""
    # Links from <iframe> data embedded within <script> - landing movie page.
    cdn_link = tamilgun.parse_links_directly_scriptdata(html_data=get(selected_movie_link))
    # 
    player_links = tamilgun.parse_all_player_links(html_data=get(cdn_link)) # 
    updated_vimeo_links = update_vimeo_links(player_links)
    updated_arivakam_links = update_arivakam_links(updated_vimeo_links)
    updated_links = update_playallu_links(updated_arivakam_links, selected_movie)
    if updated_links:
        write_movie_links(selected_movie, updated_links)
        # Write final movie links to filesystem - under "links" dir with movie name.
    return updated_links

def uow_update_player_links(params: dict, category: str, landing_page_link: str, category_func):
    """Unit of Work: Parses params, loads DB_file, updates movie player links"""
    selected_page = int(params['page'])
    selected_movie = unquote(params['name'])
    try:
        with open(f"{DATA}{os.sep}{category}{selected_page}", mode='r', encoding='utf-8') as file:
            movies: OrderedDict = json.load(file)
            if movies.get(selected_movie):
                existing_links_time = local_movie_links_checker(selected_movie)
                if existing_links_time > 10000: # setting ~3 hrs as vimeo links gets expired ~4 hours.
                    updated_links = uow_fetch_player_links(movies.get(selected_movie), selected_movie)
                elif existing_links_time and (existing_links_time < 10000):
                    try:
                        updated_links = read_movie_links(selected_movie)
                    except json.decoder.JSONDecodeError:
                        delete_movie_links(selected_movie)
                        updated_links = uow_fetch_player_links(movies.get(selected_movie), selected_movie)
                else:
                    updated_links = uow_fetch_player_links(movies.get(selected_movie), selected_movie)
            else:
                raise ValueError("Selected Movie doesn't exist!")
    except FileNotFoundError:
        category_func(page=0, html_data=get(landing_page_link))
        router(sys.argv[2][1:])
    else:
        if updated_links:
            show_player_links(selected_movie, updated_links)

def router(paramstring):
    """Router function that calls other functionsdepending on the provided paramstring"""
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if not params:
        load_movies_type()

    elif params['action'] == 'category':

        if params['category'] == 'trending':
            trending_movies = tamilgun.get_trending_movies(page=0, html_data=get(tamilgun.TRENDING))
            load_movies(category='trending', movies=trending_movies, page=0)

        elif params['category'] == 'hd':
            hd_movies = tamilgun.get_hd_movies(page=0, html_data=get(tamilgun.HD_MOVIES))
            load_movies(category='hd', movies=hd_movies, page=0)

    elif params['action'] == 'movie':

        if params['category'] == 'trending':
            uow_update_player_links(
                params=params,
                category='trending',
                landing_page_link=tamilgun.TRENDING,
                category_func=tamilgun.get_trending_movies)
            
        elif params['category'] == 'hd':
            uow_update_player_links(
                params=params,
                category='hd',
                landing_page_link=tamilgun.HD_MOVIES,
                category_func=tamilgun.get_hd_movies)
            
    elif params['action'] == 'play':
        play_video(params['url'])

    else:
        raise ValueError(f'Invalid paramstring: {paramstring}!')

# Entry point which sends the URL query to the router function.
if __name__ == '__main__':
    router(sys.argv[2][1:])
